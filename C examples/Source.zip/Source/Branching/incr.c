#include <stdio.h>

int main() {
  int a = 10;
  int b;
  b = a--;
  printf("a is %d \n b is %d \n", a, b);
  return 0;
}
