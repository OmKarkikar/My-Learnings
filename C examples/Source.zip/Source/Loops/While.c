
#include <stdio.h>

int main() {
  int count = 1;

  while (count <= 100) {
    printf("Hello");
    count = count + 1;
  }

  return 0;
}
