
#include <stdio.h>

int main() {
  int count;

  for (count = 1 ; count <= 100; count++) {
    printf("Hello");
  }

  return 0;
}
