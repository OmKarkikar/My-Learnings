
#include <stdio.h>

int main() {
  int count = 1;

  do {
    printf("Hello\n");
    count = count + 1;
  } while (count <= 10);

  return 0;
}
