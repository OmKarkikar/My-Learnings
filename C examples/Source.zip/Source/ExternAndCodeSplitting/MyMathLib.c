int add(int x, int y) {
    return x + y;
}

int sub(int x, int y) {
    return x - y;
}

int divison(int x, int y) {
    return x/y;
}
